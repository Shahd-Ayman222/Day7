namespace Day2;

public class Calculator
{
    public int Sum(int x, int y)
    {
        return x + y;
    }

    public int Sum(int x, int y, int z)
    {
        return x + y + z;
    }

    public double Sum(double x, double y)
    {
        return x + y;
    }

}