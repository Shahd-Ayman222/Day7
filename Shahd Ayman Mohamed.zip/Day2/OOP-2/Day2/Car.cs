namespace Day2;

public class Car
{

    public Car(){}
    public Car(int id, string brand, decimal price){
        Id = id;
        Brand = brand;
        Price = price;
    }

    public Car(int id) : this(id, "BMW", 10000000)
    {
    }
    public Car(int id, string brand) : this(id, brand,10 )
    {
    }
    public int Id
    {
        get;
        set;
    }
    public string Brand
    {
        get;
        set;
    }

    public decimal Price
    {
        get;
        set;
    }
    
}