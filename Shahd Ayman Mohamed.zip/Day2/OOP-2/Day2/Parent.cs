namespace Day2;

public class Parent
{
  
    public  Parent(int x, int y)
    {
        X = x;
        Y = y;
    }

    public int X
    {
        set;
        get;
    }

    public int Y
    {
        get;
        set;
    }

    public override string ToString()
    {
        return "x: " + X + " y: " + Y;
    }
    public  int Product() => X * Y;
    public virtual int Product2() => Y * X;
   
}