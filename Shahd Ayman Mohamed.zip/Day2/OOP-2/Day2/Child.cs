namespace Day2;

public class Child:Parent
{
    public int Z
    {
        set;
        get;
    }
    public Child(int x,int y,int z):base(x,y)
    {
        Z = z;
    }
  

    public override string ToString()
    {
        return base.ToString() + " z:" + Z;
    }
     public new  int Product() => X * Y * Z;
     public override int Product2() => X * Y * Z; 
}