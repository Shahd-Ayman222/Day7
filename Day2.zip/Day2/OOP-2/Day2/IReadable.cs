﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Day2
{
 public interface IReadable
    {
        public void Read();
    }
}
