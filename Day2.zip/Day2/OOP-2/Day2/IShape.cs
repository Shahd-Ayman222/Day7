﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Day2
{
  public interface IShape
    {
        public double Area
        {
            get;
        }
        public void Draw();
        public void PrintDetails()
        {
            Console.WriteLine("default method");
        }

    }
}
