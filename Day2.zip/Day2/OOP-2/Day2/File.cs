﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Day2
{
  public class File:IReadable,Writable
    {
        public void Read() {
            Console.WriteLine("File's opened for reading");
        }
        public void Write() {
            Console.WriteLine("file's opened for writing");
        }

    }
}
