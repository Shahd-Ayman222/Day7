﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Day2
{
    public abstract class Shape
    {
        public virtual void Draw()
        {
            Console.WriteLine("shape class ");
        }
        public abstract double CalcArea();


    }
}
