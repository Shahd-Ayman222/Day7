﻿using System.Diagnostics.CodeAnalysis;

namespace Day2;

class Program
{
    static void Main(string[] args)
    {
        #region Q1
        //Car car = new Car(2); // 
        //Car car2 = new Car(5, "Honda");
        //Car car3 = new Car(3, "Marsides", 2000000000);
        #endregion
        #region Q2
        // Calculator calculator = new Calculator();
        // Console.WriteLine(calculator.Sum(10,20));
        // Console.WriteLine(calculator.Sum(10,20,30));
        // Console.WriteLine(calculator.Sum(15.9,20.4));
        #endregion
        #region Q3
        Parent p=new Parent(1, 2);
        Child child = new Child(10, 20, 30);
        //Console.WriteLine(p.ToString()); 
        //Console.WriteLine(child.ToString());
        //  Parent p2=new Child(10,20,30);
        // Child c1 = new Child(1, 2, 3);
        // Console.WriteLine(p2.Product()); // calling of parent method  so it take 10,2o only 
        // Console.WriteLine(c1.Product()); // calling based on child ref  1 * 2 * 3
        // Console.WriteLine(p.Product2());
        // Console.WriteLine(p2.Product2());
        // Console.WriteLine(c1.Product2());

        #endregion
        #region 
        //IShape r = new Rectangle
        //{
        //    Length = 10,
        //    Width = 5
        //};
        //Console.WriteLine(r.Area);
        //r.Draw();
        #endregion
        #region 
        //IShape c = new Clircle();
        //c.PrintDetails();
        #endregion
        #region 
        //IMovable car = new Car();
        //car.Move();
        #endregion
        #region 
        //File f = new File();
        //f.Write();
        //f.Read();
        #endregion
        #region 
        //Shape rec = new Rectangle { 
        //    Length=6,
        //    Width=3
        //};

        //Console.WriteLine(rec.CalcArea());
        //rec.Draw();
        #endregion




    }
}