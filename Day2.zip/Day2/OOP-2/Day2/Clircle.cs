﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Day2
{
    public class Clircle:IShape
    {
        public double Raduis
        {
            get;
            set;
        }
        public double Area
        {
            get
            {
              return Math.PI*Math.Pow(Raduis,2);
            }

        }
      public void Draw()
        {
            Console.WriteLine($"Circle's drawing with raduis:{Raduis}");
        }

    }
}
