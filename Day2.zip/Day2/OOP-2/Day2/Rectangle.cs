﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Day2
{
public class Rectangle:Shape,IShape
    {
        public double Length
        {
            set;
            get;
        }
        public  double Width{
            get;
            set;
        }

        public double Area
        {
            get
            {
                return Length*Width;
            }
        }
        public override double CalcArea()
        {
            return Length*Width;
        } 
        public override void Draw()
        {
            Console.WriteLine($"the retangle's drawing with dim:{Length},{Width} ");

        }


    }
}
